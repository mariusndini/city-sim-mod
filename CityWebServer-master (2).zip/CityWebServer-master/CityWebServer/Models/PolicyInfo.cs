﻿using System;

namespace CityWebServer.Models
{
    public class PolicyInfo
    {
        public String Name { get; set; }

        public Boolean Enabled { get; set; }
    }
}