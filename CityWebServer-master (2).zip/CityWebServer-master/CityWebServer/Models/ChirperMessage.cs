﻿using System;

namespace CityWebServer.Models
{
    public class ChirperMessage
    {
        public int SenderID { get; set; }

        public String SenderName { get; set; }

        public String Text { get; set; }
    }
}