# CityWebServer
Adds a web server to Cities: Skylines

![Screenshot](http://i.imgur.com/U3dD0vd.png)
