﻿using ICities;
using UnityEngine;
using ColossalFramework;
using System;
using System.Globalization;
using ColossalFramework.UI;

namespace data
{
    class Bulldoze
    {

        public Bulldoze(ExceptionPanel panel)
        {
            PowerLineAI plAI = new PowerLineAI();
     

  


        }//end bulldoze


    }

    

}
